Thanks you for downloading this tutorial.

If you have an idea for a tutorial please contact info@videocopilot.net

LEGAL:
This tutorial is property of VideoCopilot.net
You may not sell, distribute, or otherwise make available to any 3rd party, except through videoCopilot.net
You may use the contents in you own original work but may not sell or distribute the contents as part of any stock, or tutorial collection.


Thank you
Andrew Kramer
President
VideoCopilot.net